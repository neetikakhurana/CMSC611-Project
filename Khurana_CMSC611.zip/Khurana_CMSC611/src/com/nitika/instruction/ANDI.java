package com.nitika.instruction;

public class ANDI {

	public static void result(int instNo){
		//get data for source1 and source2 and add them
		System.out.println(instNo+"In ANDI result for");
		//Integer.parseInt(InstParser.getSource1(instNo)+InstParser.getSource2(instNo)
	}
}
