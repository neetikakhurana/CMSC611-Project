package com.nitika.instruction;

import com.nitika.parsers.InstParser;

public class LUI {

	public static void result(int instNo){
		//get data for source1 and source2 and add them
		//Integer.parseInt(InstParser.getSource1(instNo)+InstParser.getSource2(instNo)
	}
}
