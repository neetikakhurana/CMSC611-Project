package com.nitika.instruction;

public class MULD {

	public static void result(int instNo){
		//get data for source1 and source2 and add them
		//Integer.parseInt(InstParser.getSource1(instNo)+InstParser.getSource2(instNo)
	//	Simulator.registers.put(Simulator.memory[instNo][2], Simulator.registers.get(Simulator.memory[instNo][3])*Simulator.registers.get(Simulator.memory[instNo][4]));

	}
}
