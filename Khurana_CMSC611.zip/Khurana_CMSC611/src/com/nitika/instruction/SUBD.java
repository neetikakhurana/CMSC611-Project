package com.nitika.instruction;

import com.nitika.main.Simulator;

public class SUBD {

	public static void result(int instNo){
		//dsub r1,r1,r2
		//Simulator.registers.put(Simulator.memory[instNo][2], Simulator.registers.get(Simulator.memory[instNo][3])-Simulator.registers.get(Simulator.memory[instNo][4]));
	}
}
