package com.nitika.enums;

public enum InstructionList {
	LW, SW, LD, SD, DADD, DADDI, DSUB, DSUBI, AND, ANDI, OR, ORI, LI, LUI, ADDD, MULTD, DIVD, SUBD, J, BEQ, BNE, HLT
}
