package com.nitika.enums;

public enum InstructionType {

	DATA_TRANSFER, ARITHMETIC_LOGICAL, SPECIAL_PURPOSE, CONTROL 
}
