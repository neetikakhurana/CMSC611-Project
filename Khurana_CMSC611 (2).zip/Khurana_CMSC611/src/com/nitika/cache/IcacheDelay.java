package com.nitika.cache;

public class IcacheDelay {
	private int delay;
	private int instNo;
	
	public int getInstNo() {
		return instNo;
	}

	public void setInstNo(int instNo) {
		this.instNo = instNo;
	}

	public int getDelay() {
		return delay;
	}

	public void setDelay(int delay) {
		this.delay = delay;
	}
}
