package com.nitika.cache;

import java.util.HashMap;
import java.util.Map;

import com.nitika.constants.ApplicationConstants;
import com.nitika.main.Simulator;
import com.nitika.parsers.InstParser;

/**
 * returns 0 if its a hit, 1 if it is a miss and 2 if it needs to wait it out
 * @author neeti
 *
 */
public class Dcache {

	public static int dataAccessRequests=0;
	public static int dataHits=0;
	public static int dataMiss=0;
	public static int delay=-1;
	public static int[] orderOfAccess0=new int[100];
	public static int[] orderOfAccess1=new int[100];
	public static int index0=0;
	public static int index1=0;
	/*
	 * within variable checks if the MMInUse is set by this cache itself
	 */
	public static boolean within=false;
	public static int dCache[][]=new int[4][4]; //size of cache given
	/*
	 * Will only be called if the isntructions are LD, SD , SW, or LW
	 */
	public static int dataInDcache(int instNo){
		if(dataAccessRequests==0){
			for(int i=0;i<4;i++){
				for(int j=0;j<4;j++){
					dCache[i][j]=-1;
				}
			}
		}
		dataAccessRequests++;
		if(delay==-1 && instNo==0)
		{
			delay=12;
		}
		else if(delay==-1 && instNo!=0)
		{
			delay=13;
		}
		int blockAddress, setOffset, blockNo, blockOffset,loc=0;
		//if the instruction is of type load
		//value to be stored 
		 //location of the word within a block
		//there are two blocks in each set with 4 words each
		if(Simulator.memory[instNo][1].contains(ApplicationConstants.LD) || Simulator.memory[instNo][1].equalsIgnoreCase(ApplicationConstants.LW))
		{
			String source=InstParser.getLDSource(instNo);
			String indexedAdd[]=new String[2];
			indexedAdd=Simulator.memory[instNo][3].split("\\(");
			loc=Integer.parseInt(indexedAdd[0])+Simulator.registers.get(source);
		}/*
		 * STORE INSTRUCTION
		 */
		else if(Simulator.memory[instNo][1].contains(ApplicationConstants.SD) || Simulator.memory[instNo][1].contains(ApplicationConstants.SW))
		{
			String source=InstParser.getStoreDest(instNo);
			String[] indexedAdd=new String[2];
			indexedAdd=Simulator.memory[instNo][3].split("\\(");
			loc=Integer.parseInt(indexedAdd[0])+Simulator.registers.get(source);
			
		}
			//calculate the set
			blockAddress=Simulator.memoryData.get(loc)/16;
			setOffset=blockAddress%2;
			//calculate to which offset in a block the word will go
			blockNo=loc/4;
			blockOffset=blockNo%4;
			//the word should go according to the set offset
			//if set is 1, it would lie in block 2 and 3 else for 0, it will be either 0 or 1
			if(setOffset==1){
				boolean flag=false;
				for(int i=2;i<4;i++){
					//if both blocks are free, then it is a data cache miss
					//check if mm is free to get the data
					if(dCache[i][blockOffset]==-1 && dCache[i+1][blockOffset]==-1 && (!Icache.MMinUse || within)){
						Icache.MMinUse=true;
						dataMiss++;
						delay--;
						within=true;
						//if both blocks are free, put it in the first block by default
						if(delay==-1){
							int k=0;
						for(int j=blockOffset;j<4;j++){
							//if the required location exists in the data.txt file. If it does, then start populating the data from this location onwards till a block's length
							if(Simulator.memoryData.containsKey(loc+k))
							{
								dCache[i][j]=loc+k;
							}
							else
							{
								dCache[i][j]=-1;
							}
							k+=4;
						}
						k=4;
						//instructions before the current one
						for(int j=blockOffset-1;j>=0;j--){
							if(Simulator.memoryData.containsKey(loc-k))
							{
								dCache[i][j]=loc-k;
							}
							else
							{
								dCache[i][j]=-1;
							}
							k+=4;
						}
						
					}
						orderOfAccess0[index0++]=i;
						flag=true;
						break;
					}
					//if the data already exists
					else if(dCache[i][blockOffset]==loc){
							dataHits++;
							orderOfAccess0[index0++]=i;
							//it's a hit
							flag=true;
							within=false;
							return 0;
					}
					//check in the other block as well
						else
						{
							flag=false;
							continue;
						}
				}
				
				
				//if the flag is not set, that means it was not found, and we need to use LRU to get that block
				/*
				 * LRU TECHNIQUE
				 */
				if(!flag && (!Icache.MMinUse || within)){
					dataMiss++;
					delay--;
					within=true;
					Icache.MMinUse=true;
					if(delay==-1){

					//1 block was least recently used
					if(orderOfAccess0[index0-1]==2){ //what if index0 is 0
						
						//if both blocks are free, put it in the first block by default
						int k=0;
						for(int j=blockOffset;j<4;j++){
							//if the required location exists in the data.txt file. If it does, then start populating the data from this location onwards till a block's length
							if(Simulator.memoryData.containsKey(loc+k))
							{
								dCache[3][j]=loc+k;
							}
							else
							{
								dCache[3][j]=-1;
							}
							k+=4;
						}
						k=4;
						//instructions before the current one
						for(int j=0;j<blockOffset;j++){
							if(Simulator.memoryData.containsKey(loc-k))
							{
								dCache[3][j]=loc-k;
							}
							else
							{
								dCache[3][j]=-1;
							}
							k+=4;
						}
						orderOfAccess0[index0++]=3;
					}
					else{
						//block 0 was least recently used
						//if both blocks are free, put it in the first block by default
						int k=0;
						for(int j=blockOffset;j<4;j++){
							//if the required location exists in the data.txt file. If it does, then start populating the data from this location onwards till a block's length
							if(Simulator.memoryData.containsKey(loc+k))
							{
								dCache[2][j]=loc+k;
							}
							else
							{
								dCache[2][j]=-1;
							}
							k+=4;
						}
						k=4;
						//instructions before the current one
						for(int j=0;j<blockOffset;j++){
							if(Simulator.memoryData.containsKey(loc-k))
							{
								dCache[2][j]=loc-k;
							}
							else
							{
								dCache[2][j]=-1;
							}
							k+=4;
						}
						orderOfAccess0[index0++]=2;
					}
				}
				}
				else{
					//main memory in use
					return 2;
				}
				if(delay==-1){
					within=false;
					return 0;
				}
				else{
					return 2;
				}
				
			}
			else if(setOffset==0)
			{
				boolean flag=false;
				for(int i=0;i<2;i++)
				{
					
					//if both blocks are free, then it is a data cache miss
					if(dCache[i][blockOffset]==-1 && dCache[i+1][blockOffset]==-1 && (!Icache.MMinUse || within))
					{
						dataMiss++;
						delay--;
						within=true;
						Icache.MMinUse=true;
						if(delay==-1){
						//if both blocks are free, put it in the first block by default
						int k=0;
						for(int j=blockOffset;j<4;j++){
							//if the required location exists in the data.txt file. If it does, then start populating the data from this location onwards till a block's length
							if(Simulator.memoryData.containsKey(loc+k))
							{
								dCache[i][j]=loc+k;
							}
							else
							{
								dCache[i][j]=-1;
							}
							k+=4;
						}
						k=4;
						//instructions before the current one
						for(int j=0;j<blockOffset;j++){
							if(Simulator.memoryData.containsKey(loc-k))
							{
								dCache[i][j]=loc-k;
							}
							else
							{
								dCache[i][j]=-1;
							}
							k+=4;
						}
						
						}
						orderOfAccess1[index1++]=i;
						flag=true;
						break;
					}
					else{
						//check if this exists in any block
						if(dCache[i][blockOffset]==loc){
							dataHits++;
							orderOfAccess1[index1++]=i;
							//it's a hit
							flag=true;
							within=false;
							return 0;
						}
						else
						{
							flag=false;
							continue;
						}
					}
				}
				
				
				//if the flag is not set, that means it was not found, and we need to use LRU to get that block
				/*
				 * LRU TECHNIQUE
				 */
				if(!flag && (!Icache.MMinUse || within)){
					dataMiss++;
					delay--;
					within=true;
					Icache.MMinUse=true;
					//1 block was least recently used
					if(delay==-1){
					if(orderOfAccess1[index1-1]==1){
						
						//if both blocks are free, put it in the first block by default
						int k=0;
						for(int j=blockOffset;j<4;j++){
							//if the required location exists in the data.txt file. If it does, then start populating the data from this location onwards till a block's length
							if(Simulator.memoryData.containsKey(loc+k))
							{
								dCache[0][j]=loc+k;
							}
							else
							{
								dCache[0][j]=-1;
							}
							k+=4;
						}
						k=4;
						//instructions before the current one
						for(int j=0;j<blockOffset;j++){
							if(Simulator.memoryData.containsKey(loc-k))
							{
								dCache[0][j]=loc-k;
							}
							else
							{
								dCache[0][j]=-1;
							}
							k+=4;
						}
						orderOfAccess1[index1++]=0;
					}
					else{
						//block 1 was least recently used
						//if both blocks are free, put it in the first block by default
						int k=0;
						for(int j=blockOffset;j<4;j++){
							//if the required location exists in the data.txt file. If it does, then start populating the data from this location onwards till a block's length
							if(Simulator.memoryData.containsKey(loc+k))
							{
								dCache[1][j]=loc+k;
							}
							else
							{
								dCache[1][j]=-1;
							}
							k+=4;
						}
						k=4;
						//instructions before the current one
						for(int j=0;j<blockOffset;j++){
							if(Simulator.memoryData.containsKey(loc-k))
							{
								dCache[1][j]=loc-k;
							}
							else
							{
								dCache[1][j]=-1;
							}
							k+=4;
						}
						orderOfAccess1[index1++]=1;
					}
					}
				}
				else{
					//main memory used by i cache
					return 2;
				}
				if(delay==-1){
					within=false;
					return 0;
				}
				else{
					return 2;
				}
			
			}
		
		
		return 0;
	}
}
